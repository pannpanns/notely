# Notely 2.6 — perbaikan

Paket ini berisi SOURCE CODE lengkap, bukan installer EXE yang sudah dibangun.
Gunakan workflow `.github/workflows/build-windows.yml` pada Windows untuk menghasilkan installer baru. Upload seluruh isi paket, termasuk folder `.github`, lalu GitHub Actions → Build Notely Lite Windows Installer → Run workflow. Unduh artifact installer setelah build berhasil.

## Perubahan
- Logo sidebar dibatasi 36×36 px; logo onboarding 64×64 px, dengan rasio asli.
- Klik Unduh model lokal: aplikasi mengunduh distribusi standalone resmi Ollama, memeriksa SHA-256 dari metadata rilis GitHub, memasang secara atomik, menjalankan layanan privat, lalu mengunduh model. Tidak perlu mencari atau memasang Ollama sendiri. Internet dan ruang disk diperlukan untuk unduhan pertama.
- Instalasi baru otomatis memakai `%LOCALAPPDATA%\Notely\NotelyModels`: `runtime\ollama` untuk mesin AI, `ollama` untuk model ringkasan, `transcription` untuk model transkripsi. Folder ini terpisah dari executable agar model tetap tersedia setelah uninstall/reinstall. Lokasi khusus yang sudah dipilih sebelumnya dipertahankan; tidak ada pemindahan/penghapusan model lama diam-diam. Lokasi masih dapat diubah melalui pengaturan.
- Uninstall menanyakan **Keep model data? / Simpan data model**. Yes merupakan pilihan bawaan, termasuk uninstall silent. No hanya menghapus folder model bertanda milik Notely; rekaman tidak ikut dihapus. Instal ulang memakai konfigurasi dan model yang dipertahankan. Pilihan ini berlaku pada uninstaller versi baru, bukan uninstaller lama yang sudah terpasang.
- Gemini: retry terbatas untuk 429/5xx dan gangguan jaringan, progres percobaan ulang, tidak bergantung pada pemuatan daftar model setiap kali merangkum. Saat model tidak ditemukan/sibuk, opsi fallback mencoba maksimal dua model Flash yang tersedia. Key salah/izin ditolak tidak dicoba berulang. Kuota dan ketersediaan Google tetap di luar kendali aplikasi.
- Teks atribusi penyedia serta pengantar umum dibuang. Ringkasan tersimpan sebelumnya dibersihkan pada tampilan tanpa mengubah file aslinya. Heading Markdown 1–6, bold, italic, daftar, kutipan, garis dan blok kode ditampilkan; HTML mentah di-escape.
- Riwayat menampilkan MB audio tiap rekaman, total MB seluruh audio, dan total termasuk catatan (1 MB = 1.000.000 byte). Tombol Hapus menawarkan audio saja atau seluruh catatan, dengan konfirmasi. Proses aktif memblokir penghapusan. Path traversal dan symlink folder ditolak.

## Verifikasi
- 56 tes Python berhasil: termasuk penghapusan di filesystem sementara, batas path, ukuran byte, penyimpanan bawaan, retry Gemini, fallback, verifikasi unduhan dan penolakan arsip berbahaya.
- Tes JavaScript format ringkasan dan notifikasi berhasil; pemeriksaan sintaks Python/JavaScript berhasil.
- API Gemini nyata belum diuji karena API key pengguna tidak tersedia.
- Unduhan runtime Windows diuji dengan respons jaringan tiruan dan checksum. Menjalankan Ollama, rekaman perangkat, serta build/install/uninstall Windows nyata belum dapat diverifikasi di lingkungan Linux ini. Workflow Windows tetap menjalankan tes yang ada.

## Uji setelah build di Windows
1. Jalankan pada akun tanpa Ollama. Pastikan folder model otomatis terbentuk; klik Unduh dan tunggu hingga model terpasang.
2. Buat transkripsi dan ringkasan lokal, lalu buka kembali aplikasi untuk memastikan model dipakai ulang.
3. Masukkan key Gemini → Muat model → pilih model teks → Tes respons → ringkas. Saat ada error, catat kode HTTP tanpa membagikan API key.
4. Uji Hapus audio saja pada rekaman percobaan: audio hilang, transkrip/ringkasan tetap, MB menurun. Uji Hapus semua pada rekaman percobaan lain.
5. Uninstall dengan Keep model data, instal ulang, pastikan model masih tersedia. Ulangi dengan No pada data model percobaan.
