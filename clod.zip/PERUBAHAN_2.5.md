# Notely 2.5.0 — perbaikan transkripsi umum

Paket ini adalah **source code**, bukan installer EXE yang sudah dibangun.

## Cara menghasilkan installer
1. Ganti isi proyek/repository dengan isi ZIP ini, termasuk folder `.github`.
2. Di GitHub Actions jalankan **Build Notely Lite Windows Installer**.
3. Unduh artifact **Notely-Lite-Windows-Installer** dari build yang berhasil.
4. Simpan rekaman, tutup Notely, lalu jalankan installer Windows.

## Gemini
Buka Pengaturan → Ringkasan AI → Layanan API → Gemini. Isi key, klik Simpan,
Muat model, pilih model teks, lalu Tes respons. Tes ini meminta jawaban singkat
ke model, bukan sekadar mengambil daftar model. Jangan membagikan key untuk debugging.
Daftar model mendukung pagination dan menyaring model gambar/TTS.
Model `models/...` dinormalisasi dan pilihan yang tidak tersedia ditolak dengan pesan jelas.
Error 401/403, 429, 400/404, jaringan dan gangguan server dibedakan.
HTTP 5xx dicoba ulang terbatas; jika opsi alternatif aktif, ringkasan dapat mencoba
hingga dua model Gemini Flash lain yang tersedia pada akun. Tidak beralih provider.
Model yang benar-benar dipakai dicatat di ringkasan; opsi ini bisa dimatikan.
Penggunaan model alternatif mengikuti kuota/tarif akun Google.

Tidak ada API key pengguna dalam paket. Respons Gemini langsung belum diuji.
HTTP 503 yang benar-benar berasal dari Google tidak dapat dihilangkan oleh aplikasi;
perbaikan menyediakan pemilihan model valid, retry, fallback dan diagnosis.

## AI lokal dan lokasi file
Pasang Ollama dari https://ollama.com/download/windows sekali.
Notely mencari executable Ollama dan menjalankan layanan tersendiri pada port loopback.
Model milik instalasi Ollama aplikasi lain tidak diubah atau dihapus.
Sebelum unduhan pertama, pilih folder melalui dialog Windows, misalnya D:\AI.
Notely membuat D:\AI\NotelyModels dengan penanda kepemilikan; unduhan Ollama
masuk subfolder ollama dan Whisper/Maleo masuk transcription.
Folder juga bisa diganti lewat Pengaturan → Ringkasan AI → AI lokal → Pilih folder.
Perubahan folder tidak memindahkan model lama otomatis: folder baru memiliki katalog
sendiri. Folder sebelumnya tetap tercatat untuk pembersihan saat uninstall.
Jangan mencampurkan dokumen pribadi ke dalam NotelyModels.

Tombol Hapus model menghapus model di katalog aktif melalui API DELETE Ollama.
Blob yang masih digunakan model lain boleh tetap ada sampai model terakhir dihapus.
Uninstall Notely membersihkan folder NotelyModels bertanda milik aplikasi yang
tercatat, termasuk di drive lain yang terhubung. Rekaman di Documents/Notely dipertahankan.
Drive yang sedang tidak tersambung tidak dapat dibersihkan; sambungkan sebelum uninstall.
Folder yang berisi junction/symlink ditolak untuk mencegah penghapusan data lain.
Model lama di cache bersama Hugging Face atau ~/.ollama dari versi sebelumnya
bukan milik penyimpanan baru ini dan tidak dihapus otomatis.
Runtime CUDA opsional lama tetap mengikuti lokasi sebelumnya.

## API key
API key disimpan per penyedia menggunakan Windows DPAPI (akun pengguna aktif),
di %LOCALAPPDATA%\Notely\preferences.json dalam bentuk ciphertext.
Tidak disimpan dalam localStorage, log, source ZIP, atau server pembuat aplikasi.
Key tetap digunakan untuk menghubungi penyedia yang dipilih; transkrip dikirim
setelah persetujuan dialog. Lokal bukan berarti bebas risiko: proses yang berjalan
sebagai pengguna Windows yang sama masih dapat mengakses key.
Kosongkan kolom key lalu Simpan untuk menghapus key penyedia tersebut.

## Antarmuka
Istilah rapat diganti menjadi rekaman/transkripsi. Format catatan berlaku untuk
kuliah, wawancara, diskusi, video, dan audio umum.
Aktivitas unduhan berhasil hilang setelah 5 detik; kegagalan setelah 12 detik.
Polling tidak memunculkan kembali aktivitas yang sudah ditutup. Proses aktif tetap tampil.
Logo N berbentuk gelombang suara digunakan pada sidebar, onboarding, favicon,
serta ikon PNG/ICO untuk aplikasi dan installer.

## Validasi
43 pengujian Python lulus, termasuk 10 pengujian baru; satu pengujian JavaScript
untuk siklus notifikasi lulus. Sintaks backend diperiksa kompatibel Python 3.11.
Enkripsi DPAPI diuji dengan substitusi fungsi dalam lingkungan Linux, bukan Windows asli.
Build Tauri/NSIS, dialog folder Windows, Job Object, instalasi/uninstall dan unduhan
model ukuran penuh perlu diuji pada Windows. Workflow build disertakan.
Render browser penuh belum dapat dilakukan karena Chromium tidak tersedia dan
unduhannya gagal di lingkungan pengerjaan ini.

Sumber teknis:
- https://ai.google.dev/gemini-api/docs/troubleshooting
- https://ai.google.dev/api/models
- https://docs.ollama.com/faq
- https://docs.ollama.com/api/delete
