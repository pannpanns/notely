# Perbaikan 2.4.1

- Transkrip dan ringkasan tampil berdampingan, dengan scroll terpisah.
- Error server sementara HTTP 500/502/503/504 dicoba ulang maksimal tiga kali dengan jeda meningkat. HTTP 400/401/403/429 tidak dicoba otomatis.
- HTTP 503 dijelaskan sebagai model sedang sibuk, bukan kesalahan API key. Jika tetap gagal, pesan dan tombol coba lagi tetap terlihat di panel ringkasan.
- Model tidak diganti diam-diam. Pilih model Gemini lain melalui Model AI bila layanan masih sibuk.
- API key untuk daftar model Gemini dikirim lewat header, tidak lewat URL.
- Pemanggilan nvidia-smi dan subprocess pemasangan CUDA memakai CREATE_NO_WINDOW di Windows.
- Welcome muncul sebelum pemeriksaan GPU/audio selesai. Tombol persiapan aktif setelah pemeriksaan selesai.
- Lima tes khusus perbaikan lulus; UI Chromium lulus tanpa error JavaScript.
- Belum diuji di Windows fisik dan belum menggunakan API key pengguna. Retry tidak menjamin server Gemini tersedia.

Untuk menerapkan perubahan, build ulang installer melalui workflow Windows, lalu pasang versi baru. ZIP ini berisi source, bukan EXE.

Rujukan error Gemini: https://ai.google.dev/gemini-api/docs/troubleshooting

---

# Notely 2.4 | Pembaruan Clod

## Yang berubah

- Beranda dengan dua aksi utama dan daftar catatan terakhir.
- Tab Transkrip dan Ringkasan menggantikan dua panel yang selalu terbuka.
- Konteks tambahan tersimpan di panel lipat; transkrip bisa diedit.
- AI Lokal berada pertama dan menjadi default untuk pengaturan baru. Preferensi lama tetap dihormati.
- Qwen 3.5 4B dan Qwen 3.5 2B menjadi dua kartu utama. Model lama tetap tersedia.
- Ukuran model lokal menggunakan manifest registry, lalu ukuran terpasang dari Ollama. Jika jaringan gagal, estimasi ditandai ≈.
- Ukuran Whisper/Maleo diambil dari metadata file repository, hanya untuk file yang digunakan.
- Notifikasi pojok menampilkan progres byte, total, kecepatan transfer dan ETA. Progres tetap terlihat saat berpindah halaman.
- Lapisan Ollama dijumlahkan agar progres tidak kembali ke nol setiap pergantian lapisan. Byte yang sudah ada dari cache tidak dihitung sebagai kecepatan jaringan.
- Unduhan terputus tidak dianggap sukses. Tombol coba lagi tersedia. Satu unduhan Ollama berjalan pada satu waktu.
- Unduhan transkripsi melaporkan byte melalui callback Hugging Face Hub 1.33+; cache tetap dipakai ketika model sudah lengkap.
- Runtime Python dipasang langsung di folder executable. Folder package yang diperlukan tetap dipertahankan.
- Installer menggunakan ZLIB, dengan pengukuran durasi instalasi di CI. CUDA tetap opsional dan tidak dibundel.

## Cara melihat dan membangun

1. Ekstrak paket. Buka `frontend/index.html` untuk melihat UI. Browser biasa tidak menjalankan mesin audio atau AI desktop.
2. Untuk aplikasi Windows, unggah semua source termasuk `.github/workflows` ke repository Anda.
3. Jalankan workflow **Build Notely Lite Windows Installer** melalui GitHub Actions.
4. Ambil artifact **Notely-Lite-Windows-Installer** setelah build dan pengujian installer lulus.
5. Jalankan Ollama di Windows. Buka Pengaturan > Ringkasan AI > AI lokal, pilih model, lalu Unduh. Setelah terpasang model dapat dipakai tanpa mengirim transkrip ke layanan API.

## Batas verifikasi

- Source Python/JavaScript diperiksa, unit test unduhan memakai respons terkendali, dan UI diuji di Chromium.
- Model besar tidak diunduh dan inferensi Ollama/CUDA nyata belum diuji di lingkungan ini.
- Build `.exe`, audio Windows WASAPI, instalasi, upgrade, dan uninstall harus lulus workflow Windows yang disertakan. Paket ini adalah source code, bukan installer siap pakai.
- ZLIB dipilih untuk memprioritaskan ekstraksi. Installer bisa lebih besar; kecepatan akhirnya bergantung pada disk, antivirus, dan WebView2. Tidak ada klaim peningkatan waktu tanpa benchmark Windows.
- Folder `_internal` bukan penyebab tunggal instalasi lambat. Mengubah lokasi file tidak mengurangi jumlah byte yang perlu ditulis.
- AI lokal menggunakan Ollama, bukan runtime GGUF bawaan Meetily. Karena itu ukuran Qwen bisa berbeda dari gambar Meetily.
- GB memakai satuan desimal. Ukuran disk berbeda dari RAM/VRAM. Kecepatan yang ditampilkan adalah laju transfer unduhan, bukan kecepatan maksimum Wi-Fi.
- Katalog ukuran Whisper memerlukan jaringan saat belum pernah dimuat; jika tidak tersedia UI menyatakan ukuran belum tersedia, bukan angka fiktif.

## Rujukan implementasi

- Source Meetily yang dilampirkan, terutama katalog summary models dan tampilan pilihan model. Tidak menyalin implementasi UI Meetily.
- https://ollama.com/library/qwen3.5
- https://www.pyinstaller.org/en/stable/usage.html (contents-directory)
- https://v2.tauri.app/reference/config/ (NSIS compression)
- API publik huggingface_hub 1.33+, snapshot_download dan tqdm_class.

Gambar pada folder preview memakai data contoh untuk pemeriksaan desain, bukan hasil rapat atau unduhan nyata.
