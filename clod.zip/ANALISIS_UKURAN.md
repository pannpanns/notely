# Analisis source yang dilampirkan

| Bagian | Meetily | Notely awal | Implementasi hasil |
| --- | --- | --- | --- |
| Desktop | Tauri + frontend web | Tauri + HTML/JS | Dipertahankan |
| Speech engine | whisper-rs native; juga ort/Parakeet | Python + Faster-Whisper + CT2 | Engine dipertahankan agar model Maleo CT2 tetap kompatibel |
| Audio resampling | rubato/native Rust | scipy.signal.resample_poly | PyAV/libswresample yang sudah tersedia |
| Model | Download/cache lewat manager Rust | Download/cache Hugging Face | Tetap terpisah dari installer |
| GPU Windows | Feature CUDA/Vulkan opsional | CUDA diunduh opsional | Tetap opsional, NVIDIA dikecualikan dari paket |
| Packaging | Native Rust + sidecars llama-helper/FFmpeg | PyInstaller onefile dengan collect-all luas | Onedir + collect terarah + venv bersih + pemeriksaan paket |
| Ukuran aktual | Tidak ada installer pembanding | Tidak ada installer pembanding | Diukur oleh GitHub Actions, belum tersedia lokal |

Dasar pembacaan source Meetily:
- `frontend/src-tauri/Cargo.toml`: whisper-rs, ort, rubato, feature GPU per platform.
- `frontend/src-tauri/tauri.conf.json`: resource template dan sidecar llama-helper/ffmpeg.
- `frontend/src-tauri/src/whisper_engine/whisper_engine.rs`: state download model,
  pemeriksaan file dan pembatalan download.

Dasar Notely:
- `backend/engine/core.py`: SciPy dipakai hanya untuk konversi sample rate.
- `backend/engine/model_runtime.py`: model Maleo memakai subfolder CT2 int8.
- `backend/engine/cuda_setup.py`: paket NVIDIA eksternal sudah ada sejak awal.
- `.github/workflows/build-windows.yml`: koleksi paket luas dan tidak ada uji EXE.

Tidak ada kode Meetily yang disalin langsung; pola pengemasan dipelajari lalu
perubahan dibuat di Notely. Tidak ada klaim bahwa Notely sudah berubah menjadi
whisper.cpp/whisper-rs. Mengganti engine tanpa memigrasikan model dapat menghilangkan
model bahasa Indonesia terlatih yang saat ini tersedia.

Dokumentasi teknis:
- https://pyav.org/docs/develop/api/audio.html
- https://v2.tauri.app/reference/config/
- https://v2.tauri.app/distribute/windows-installer/

Perbandingan yang adil: build ZIP awal dan proyek ini pada runner/versi dependensi
yang sama, bandingkan EXE installer dan folder terpasang sebelum mengunduh model.
Lalu ukur cache model/CUDA dan rekaman secara terpisah. Jangan bandingkan ukuran
source ZIP dengan installer atau disk setelah semua model diunduh.
