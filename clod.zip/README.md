# Notely 2.6

Lihat PERBAIKAN_2.6.md untuk perubahan terbaru, lokasi model dan opsi uninstall. Catatan di bawah adalah riwayat versi sebelumnya.

# Notely 2.4.0 | UI fokus dan AI lokal

Paket ini melanjutkan optimasi ukuran Notely dengan **PyInstaller onedir**.
Engine tidak lagi menyatukan semua dependensi ke dalam satu EXE.

## Isi folder instalasi

| Item | Fungsi |
| --- | --- |
| notely-desktop.exe | Antarmuka Tauri |
| notely-engine.exe | Peluncur engine Python |
| python311.dll dan folder pustaka | Python runtime, DLL, CTranslate2, NumPy, PyAV, ONNX dan pustaka pendukung |
| uninstall.exe | Uninstaller |

Jangan memindahkan EXE sendirian atau menghapus pustaka pendukung. Tauri memasang folder
ini di samping engine. Model transkripsi dan CUDA opsional tetap diunduh terpisah.
Folder terpasang dapat lebih besar dari versi onefile karena file sudah diekstrak.
Installer NSIS memakai ZLIB untuk memprioritaskan ekstraksi; ukuran installer bisa lebih besar. Jumlah file lebih banyak bukan berarti fitur
bertambah; engine tidak perlu mengekstrak seluruh runtime setiap kali dibuka.

## Perbaikan penghentian engine

1. Desktop menghentikan child saat jendela dihancurkan, ketika exit disetujui,
   dan pada event Exit. Proteksi penutupan saat merekam tetap dipertahankan.
2. Engine memegang handle Windows untuk proses desktop dan keluar jika desktop
   mati/crash/dihentikan paksa. Tidak mengandalkan pengecekan PID berulang yang
   dapat tertukar dengan proses baru. Ini bukan pemulihan rekaman akibat crash.
3. Hook preinstall/preuninstall menghentikan engine yang EXE-nya berada tepat di
   folder instalasi tersebut, termasuk proses onefile versi lama yang tertinggal.
   Tidak memakai penghentian global semua Python atau semua engine berdasarkan nama.
4. Jika desktop masih aktif, cleanup meminta pengguna menyimpan dan menutupnya.
   Jika cleanup gagal, proses instalasi/uninstall dibatalkan agar file yang sedang
   dipakai tidak dihapus paksa. Hook tidak menghapus rekaman, model, atau cache CUDA.

Windows PowerShell bawaan diperlukan untuk cleanup installer. Error cleanup
terlihat dalam dialog, bukan diabaikan. Proteksi ini ada di installer BARU;
uninstaller lama yang sudah terpasang tidak berubah sebelum upgrade.

## Build melalui GitHub

1. Ekstrak ZIP dan upload **isi folder Notely-Optimized** ke root repository.
   Sertakan semua perubahan: backend, scripts, src-tauri (termasuk windows), tests,
   frontend, dan .github/workflows/build-windows.yml. Jangan hanya mengganti workflow.
2. Jangan upload folder dist, target, .venv, binaries/runtime atau model hasil
   build. Workflow membuat seluruh file runtime tersebut di runner Windows.
3. Commit lalu Actions → Build Notely Lite Windows Installer → Run workflow.
4. Download artifact Notely-Lite-Windows-Installer, ekstrak dan jalankan setup
   versi 2.3.2. Report ukuran/versi dependensi tersedia pada Notely-Build-Reports.
5. Stop dan simpan rekaman sebelum upgrade. Jika engine versi lama masih muncul
   setelah aplikasi/uninstaller lama ditutup, akhiri notely-engine.exe milik
   instalasi itu melalui Task Manager lalu pasang versi baru pada folder yang sama.

Workflow memakai UTF-8 dan venv bersih. Smoke test menjalankan EXE dari folder dist
serta folder staging Tauri untuk menangkap DLL yang tertinggal sebelum build.
Tes Windows juga mematikan proses owner tiruan untuk memverifikasi engine ikut
keluar, lalu menjalankan cleanup PowerShell pada engine yatim untuk verifikasi.
Workflow juga memasang installer secara silent di folder sementara, menjalankan
engine terpasang, lalu uninstall dengan engine yatim masih aktif. Proses engine
dan folder runtime harus hilang sebelum artifact diunggah. Semua pemeriksaan
Windows ini menjadi gate build, belum dijalankan dari lingkungan Linux ini.

## UI dan fitur

Aplikasi terbuka maximized dengan title bar native, tombol minimize, restore/
maximize, resize dan X. Fullscreen nonaktif. Ukuran restore 1100 x 720.
Faster-Whisper dan model Maleo Indonesia dipertahankan. SciPy diganti resampling
PyAV; model/CUDA tidak masuk installer; shell Rust dioptimalkan ukurannya.
Ini belum migrasi ke engine Rust whisper-rs seperti Meetily.

## Status validasi

21 tes lokal lulus, termasuk resampling audio dan unit test parent watcher dengan
Windows API tiruan. Sintaks Python diperiksa. **Belum build atau menjalankan
installer 2.3.2 di Windows**. Uji nyata diperlukan untuk rekaman, CUDA, minimize/
restore, close normal, kill desktop, upgrade dari onefile, dan uninstall.

Batas 600 MiB engine folder tidak terkompresi adalah gate regresi, bukan klaim
ukuran hasil. Dependensi memakai rentang versi; laporan pip freeze dan Cargo.lock
mencatat versi build. Bandingkan ukuran installer, folder aplikasi, cache model,
CUDA dan rekaman secara terpisah. Installer belum ditandatangani.

## Perbaikan 2.3.2: cleanup dari NSIS 32-bit

Build 2.3.1 pengguna berhasil membuat installer 64,40 MiB dan lulus pengujian
engine serta parent-death, tetapi gagal mengakhiri engine saat uninstall nyata.
Cleanup sebelumnya menggunakan Get-Process.Path; properti ini dapat kosong
ketika PowerShell 32-bit memeriksa proses 64-bit. Perbaikan:
- Hook memilih PowerShell native lewat Sysnative jika tersedia.
- Script cleanup juga otomatis beralih ke PowerShell 64-bit jika dipanggil dari x86.
- Lokasi proses yang tidak dapat dibaca menyebabkan kegagalan eksplisit, bukan
  menganggap tidak ada engine. Proses tetap dicocokkan dengan folder instalasi.
- Smoke test sengaja memanggil cleanup lewat PowerShell 32-bit untuk regresi.
- Log cleanup dicatat di TEMP/Notely-cleanup.log dan disalin ke build_reports
  pada pengujian installer. Kode exit uninstaller diperiksa.

Tes uninstall asli tetap wajib lulus; tidak dilewati. Build 2.3.2 belum dijalankan
pada Windows dari lingkungan pengembangan ini.
